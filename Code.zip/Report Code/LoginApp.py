from kivymd.app import MDApp
from kivy.lang import Builder
from kivy.core.window import Window
from kivy.uix.widget import Widget
from kivy.uix.image import Image
from kivy.clock import Clock
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.logger import Logger
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import Screen, ScreenManager
from kivy.properties import StringProperty
from kivy.uix.stacklayout import StackLayout
from kivy.uix.relativelayout import RelativeLayout
from kivymd.uix.filemanager import MDFileManager
from kivy.uix.camera import Camera 
from kivy.graphics.texture import Texture
import kivy.core.text
import cv2
import time
from kivymd.toast import toast
from kivy.uix.boxlayout import BoxLayout
from kivy.base import runTouchApp
from kivy_garden.mapview import MapView 
import sys
import tweepy
import os
from twitter import Twitter
from kivy.storage.jsonstore import JsonStore
from kivy.config import Config
Config.set('graphics', 'borderless', False)
Config.write()
#----------------------------------------------------------------------------------
# -----------------------Twitter API Key's-------------------------
consumer_key = "******************************************"
consumer_secret = "******************************************"
access_token = "******************************************"
access_token_secret = "******************************************"
#----------------------------------------------------------------------------------
global_image_path = ""
Window.size = (300,500)
#----------------------------------------------------------------------------------
    #----------------------------------------------------------------------------------
                            #---------Validation Start---------
    #----------------------------------------------------------------------------------
class LoginPage(Screen):
    def verify_credentials(self):
        store = JsonStore('credentials/credentials.json')
        if self.ids["login"].text == store.get('ID')['username'] and self.ids["password"].text == store.get('ID')['password']:
            self.ids["login"].text = ""
            self.ids["password"].text = ""
            self.manager.current = "MenuScreen"
        else:
            toast("Invalid username or password")
    #----------------------------------------------------------------------------------
                            #---------Validation End---------
    #----------------------------------------------------------------------------------
#----------------------------------------------------------------------------------
class UserPage(Screen):
    def back_function(self):
        self.manager.current = "MenuScreen"
#----------------------------------------------------------------------------------
class ScreenManagement(ScreenManager):
    pass
#----------------------------------------------------------------------------------
class MenuScreen(Screen):
    def log_logout(self):
        self.manager.current = "login"

    def user_page(self):
        self.manager.current = "user"

    def google_page(self):
        self.manager.current = "googledisplaypage"

    def twitter_upload(self):
        self.manager.current = "TwitterUpload"
#----------------------------------------------------------------------------------
class CamBoxLayout(Screen):
    def back_function(self):
        self.manager.current = "TwitterUpload"
    #----------------------------------------------------------------------------------
                            #---------Camera Start---------
    #----------------------------------------------------------------------------------
    def camera_click_function(self):
        # Capturing image and saving the image
        camera = self.ids['Camera_id']
        timestr = time.strftime("%Y%m%d_%H%M%S")
        camera.export_to_png("camera_images/IMG_{}.png".format(timestr))
        print("Image Captured")
    #----------------------------------------------------------------------------------
                            #---------Camera End---------
    #----------------------------------------------------------------------------------
#----------------------------------------------------------------------------------
class TwitterUpload(Screen):
    def back_function(self):
        self.manager.current = "MenuScreen"

    def capture(self):
        self.manager.current = "camlay"
    #----------------------------------------------------------------------------------
                            #---------Twitter Upload Start---------
    #----------------------------------------------------------------------------------
    def up_on_press(self):
        # OAuth process, using the keys and tokens
        auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
        auth.set_access_token(access_token, access_token_secret)
        # Creation of the actual interface, using authentication
        api = tweepy.API(auth)
        # Creates the user object. The me() method returns the user whose authentication keys were used.
        user = api.me()
        # Assigning the value in the text field
        global_image_path = self.ids["id_img_select"].text
        if global_image_path != "no file selected":
            if user:
                # Show User Details in terminal
                print('Name: ' + user.name)
                print('Location: ' + user.location)
                print('Friends: ' + str(user.friends_count))
                # Loading the image
                global_image_path = self.ids["id_img_select"].text
                imagePath = global_image_path           
                status = self.ids["upload_input_text"].text
                api.update_with_media(imagePath, status)
    #----------------------------------------------------------------------------------
                            #---------Store to Json File Start---------
    #----------------------------------------------------------------------------------
                timesave = time.strftime("%Y-%m-%d_%H:%M:%S")
                store = JsonStore('SaveFile.json')
                store.put('Twitter Content_{}'.format(timesave), content=status, picture=imagePath, time=timesave, lat=56.8880025858352, lon=14.80999532113433)
    #----------------------------------------------------------------------------------
                            #---------Store to Json File End---------
    #----------------------------------------------------------------------------------
                self.ids["id_img_select"].text = "no file selected"
                self.ids["upload_input_text"].text = ""
                toast("Tweet Successful")
            else:
                toast("Tweet Failed")
        else:
            toast("No File Selected")
            
    #----------------------------------------------------------------------------------
                            #---------Twitter Upload End---------
    #----------------------------------------------------------------------------------

    #------------------------------------------------------------------------------------------------------------------

    #----------------------------------------------------------------------------------
                            #---------File Manager Start---------
    #----------------------------------------------------------------------------------
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        Window.bind(on_keyboard=self.events)
        self.manager_open = False
        self.file_manager = MDFileManager(
            exit_manager=self.exit_manager,
            select_path=self.select_path,
            previous=True,
        )
    def file_manager_open(self):
        self.file_manager.show('/')  # output manager to the screen
        self.manager_open = True
    def select_path(self, path):
        '''It will be called when you click on the file name
        or the catalog selection button.

        :type path: str;
        :param path: path to the selected directory or file;
        '''
        self.ids["id_img_select"].text = path
        global_image_path = self.ids["id_img_select"].text
        self.exit_manager()
        #Display the path of the selected file
        toast(global_image_path)

    def exit_manager(self, *args):
        '''Called when the user reaches the root of the directory tree.'''

        self.manager_open = False
        self.file_manager.close()

    def events(self, instance, keyboard, keycode, text, modifiers):
        '''Called when buttons are pressed on the mobile device.'''

        if keyboard in (1001, 27):
            if self.manager_open:
                self.file_manager.back()
        return True
    #----------------------------------------------------------------------------------
                            #---------File Manager End---------
    #----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------------
class MapViewApp(Screen):
    def back_function(self):
        self.manager.current = "MenuScreen"
#----------------------------------------------------------------------------------
class LoginApp(MDApp):
    def builder(self):
        return Builder.load_file('login.kv')
#----------------------------------------------------------------------------------
if __name__ == '__main__':
    LoginApp().run()